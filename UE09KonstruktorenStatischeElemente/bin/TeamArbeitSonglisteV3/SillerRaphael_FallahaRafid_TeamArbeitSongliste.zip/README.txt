-------------------TeamArbeitSongliste-------------------
Ein Verwaltungsprogramm für eine Musikbibliothek.
Es können Titel, ALbum, Interpret und Erscheinungsjahr
gespeichert werden.
Außerdem gibt es einen optionalen Darkmode.

Beim Start des Programmes wird man nach dem Speicherort der Datei gefragt,
von der man lesen/speichern möchte.
Mit den oberen 4 Knöpfe kann man durch die einzelnen Datensätze navigieren.
Mit Neu wird ein neuer Datensatz erstellt.
Mit löschen wird der aktuelle Datensatz gelöscht.
Mit Alle löschen werden alle Datensätze gelöscht.

Autoren sind:
Raphael Siller
Rafid Fallaha
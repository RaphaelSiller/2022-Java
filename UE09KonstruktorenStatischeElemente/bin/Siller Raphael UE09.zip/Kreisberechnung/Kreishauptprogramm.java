package Kreisberechnung;

public class Kreishauptprogramm {

	public static void main(String[] args) {
		KreisGUI fenster = new KreisGUI();

	}

}

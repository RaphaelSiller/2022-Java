package jumpingBalls;

public class JumpingBallsHauptprogramm {

	public static void main(String[] args) {
		JumpingBalls fenster = new JumpingBalls();
	}

}
